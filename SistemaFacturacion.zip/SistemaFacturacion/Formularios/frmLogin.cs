﻿using SistemaFacturacion.Clases;
using SistemaFacturacion.Formularios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaFacturacion
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void brnCancelar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (txtUsuario.Text == "")
            {
                MessageBox.Show("Debe ingresar un usuario", "Error");
                txtUsuario.Focus();
                return;
            }
            if (txtClave.Text == "")
            {
                MessageBox.Show("Debe ingresar una clave", "Error");
                txtClave.Focus();
                return;
            }

            if(!Datos.ValidarUsuario(txtUsuario.Text, txtClave.Text))
            {
                MessageBox.Show(Datos.Mensaje);
                txtUsuario.Focus();
                return;
            }

            frmPrincipal miPrincipal = new frmPrincipal();
            miPrincipal.Show();
            this.Hide();
            
        }
        }
    }
		 

    