﻿using LibLlenarGrids;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LibParametros;
using LibConexionBD;
using LibLlenarCombos;


namespace SistemaFacturacion.Formularios
{

    //FORMULARIO PARA LA CONSULTA DE ARTICULOS DONDE SE CARGARAN TODOS LOS PRODUCTOS DE LA TABLA PRODUCTO BASE DE DATOS FACTURACION LB 2017
    public partial class frmConsultaArticulos : Form
    {


        //Declarar objetos para llenargrids, y llenarcombos LB 2017
        LlenarGrids llenarGrids = new LlenarGrids("Parametros.xml");
        LlenarCombos llenarCombos = new LlenarCombos("Parametros.xml");
      

        //Inicializa el formulario LB 2017
        public frmConsultaArticulos()
        {
            InitializeComponent();
        }

        //nada LB 2017
        private void dgvProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        //metodo que carga el formulario consultar articulos al abrirlo LB 2017
        private void frmConsultaArticulos_Load(object sender, EventArgs e)
        {
            //llenar data grid de productos con un query para la tabla producto, propiedad .SQL ingresar la instruccion SQL propiedad llenargridwindows() metodo para llenar el data grid
            //Ingresar el nombre del datagrid como parametro
            llenarGrids.SQL = "SELECT dbo.Producto.IDProducto, dbo.Producto.Descripcion, dbo.Producto.Precio, dbo.Producto.Stock, dbo.Producto.Notas, dbo.IVA.Descripcion AS IVA, dbo.Departamento.Descripcion AS Departamento FROM dbo.Producto INNER JOIN dbo.IVA ON dbo.Producto.IDIVA = dbo.IVA.IDIVA INNER JOIN dbo.Departamento ON dbo.Producto.IDDepartamento = dbo.Departamento.IDDepartamento";
            llenarGrids.LlenarGridWindows(dgvProductos);

            //llenar el objeto combo box // propiedad .SQL declaramos la variable SQL // propiedad .CampoID seleccionamos el ID oculto, // propiedad .CampoTexto lo que queremos mostrar
            //llenarcombowindows metodo para llenar el combo box ingresar el nombre del combo box como parametro;
            llenarCombos.SQL = "select IDDepartamento, Descripcion from Departamento UNION SELECT '','[Todos]' Order by Descripcion";
            llenarCombos.CampoID = "IDDepartamento";
            llenarCombos.CampoTexto = "Descripcion";
            llenarCombos.LlenarComboWindows(cmbDepartamento);

            llenarCombos.SQL = "select IDIVA, Descripcion from IVA UNION SELECT '','[Todos]' Order By Descripcion";
            llenarCombos.CampoID = "IDIVA";
            llenarCombos.CampoTexto = "Descripcion";
            llenarCombos.LlenarComboWindows(cmbIva);
        }

        private void Departamento(object sender, EventArgs e)
        {

        }

        private void cmbDepartamento_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbDepartamento.SelectedIndex == 0)
            {
                llenarGrids.SQL = "SELECT dbo.Producto.IDProducto, dbo.Producto.Descripcion, dbo.Producto.Precio, dbo.Producto.Stock, dbo.Producto.Notas, dbo.IVA.Descripcion AS IVA, dbo.Departamento.Descripcion AS Departamento FROM dbo.Producto INNER JOIN dbo.IVA ON dbo.Producto.IDIVA = dbo.IVA.IDIVA INNER JOIN dbo.Departamento ON dbo.Producto.IDDepartamento = dbo.Departamento.IDDepartamento";
                llenarGrids.LlenarGridWindows(dgvProductos);
            }
            else
            {
                llenarGrids.SQL = "SELECT dbo.Producto.IDProducto, dbo.Producto.Descripcion, dbo.Producto.Precio, dbo.Producto.Stock, dbo.Producto.Notas, dbo.IVA.Descripcion AS IVA, dbo.Departamento.Descripcion AS Departamento FROM dbo.Producto INNER JOIN dbo.IVA ON dbo.Producto.IDIVA = dbo.IVA.IDIVA INNER JOIN dbo.Departamento ON dbo.Producto.IDDepartamento = dbo.Departamento.IDDepartamento WHERE dbo.Producto.IDDepartamento = " + cmbDepartamento.SelectedValue; ;
                llenarGrids.LlenarGridWindows(dgvProductos);
            }
        }

        private void cmbIva_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbIva.SelectedIndex == 0)
            {
                llenarGrids.SQL = "SELECT dbo.Producto.IDProducto, dbo.Producto.Descripcion, dbo.Producto.Precio, dbo.Producto.Stock, dbo.Producto.Notas, dbo.IVA.Descripcion AS IVA, dbo.Departamento.Descripcion AS Departamento FROM dbo.Producto INNER JOIN dbo.IVA ON dbo.Producto.IDIVA = dbo.IVA.IDIVA INNER JOIN dbo.Departamento ON dbo.Producto.IDDepartamento = dbo.Departamento.IDDepartamento";
                llenarGrids.LlenarGridWindows(dgvProductos);
            }
            else
            {
                llenarGrids.SQL = "SELECT dbo.Producto.IDProducto, dbo.Producto.Descripcion, dbo.Producto.Precio, dbo.Producto.Stock, dbo.Producto.Notas, dbo.IVA.Descripcion AS IVA, dbo.Departamento.Descripcion AS Departamento FROM dbo.Producto INNER JOIN dbo.IVA ON dbo.Producto.IDIVA = dbo.IVA.IDIVA INNER JOIN dbo.Departamento ON dbo.Producto.IDDepartamento = dbo.Departamento.IDDepartamento WHERE dbo.IVA.IDIVA= " + cmbIva.SelectedValue;
                llenarGrids.LlenarGridWindows(dgvProductos);
            }
        }
    }
}
