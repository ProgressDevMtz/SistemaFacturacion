﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaFacturacion.Formularios
{
    public partial class frmPrincipal : Form
    {
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void archivoToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void salirToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void movimientosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ayudaToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        //Hacer hijo a los formularios que abran los menus
        private void consultaProductosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConsultaArticulos miFormulario = new frmConsultaArticulos();
            miFormulario.MdiParent = this;
            miFormulario.Show();
        }

        private void frmPrincipal_Leave(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
          salirToolStripMenuItem1_Click(sender, e);
        }

        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmArticulos miFormulario = new frmArticulos();
            miFormulario.MdiParent = this;
            miFormulario.Show();
        }
    }
}
