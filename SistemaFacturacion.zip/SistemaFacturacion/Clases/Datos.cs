﻿using LibConexionBD;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaFacturacion.Clases
{
    class Datos
    {
        //Clase que manipula datos
        

        //atributos
        private static string mensaje;
        private static ConexionBD conexion = new ConexionBD("Parametros.xml");

        //propiedad
        public static string Mensaje { get { return mensaje;} }

        //metodos

        public static bool ValidarUsuario(string usuario, string clave)
        {
            if (!conexion.AbrirConexion())
            {
                mensaje = conexion.Error;
                conexion.CerrarConexion();
                return false;
            }

            conexion.SQL = "Select (1) from Usuario where Usuario = '" + usuario + "' and Clave = '" + clave + "'";
            if (!conexion.ConsultarValorUnico(false))
            {
                mensaje = conexion.Error;
                conexion.CerrarConexion();
                return false;
            }

            if (conexion.ValorUnico == null)
            {
                mensaje = "Usuario o contrasena no valida";
                conexion.CerrarConexion();
                return false;
            }

            conexion.CerrarConexion();
            return true;
        }
    }
}
